import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:sahabatjaya/constanta/constanta.dart';
import 'package:sahabatjaya/engines/bits/bits_filter.dart';

class APIBitsNode {

  Future<Map> getPost(BitsFilter filter) async {
    final url = '$CHOST_ADDR/bits/BasicQuery/show';
    Map<String, dynamic> reqBody = filter.toJsonAPI();
//    reqBody.putIfAbsent("posDB", () => 1);
    print(url + " body: " + jsonEncode(reqBody));
    final response = await http.post(url, body:jsonEncode(reqBody), headers: {"Content-type": "application/json", "token":"eyJhbGciOiJIUzI1NiJ9.MDg1Mjk5NTkzMTY2.jXRDV8XLuR6HPoXA5zYQrp_TDB02KzpiktDGoEkVL-U"});
//    print(response.body['isidata'].length);
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception("Unable to perform request!");
    }
  }

  Future<Map> postBasicQuery(String sqlText, List<dynamic> data) async {
    final url = '$CHOST_ADDR/bits/BasicQuery/raw';
    Map<String, dynamic> reqBody = {"text": sqlText, "values": data};
    final response = await http.post(url, body:jsonEncode(reqBody), headers: {"Content-type": "application/json", "token":"eyJhbGciOiJIUzI1NiJ9.MDg1Mjk5NTkzMTY2.jXRDV8XLuR6HPoXA5zYQrp_TDB02KzpiktDGoEkVL-U"});
    print(response.body);
    if (response.statusCode == 200) {
      print(jsonDecode(response.body)['isidata']);
      return jsonDecode(response.body);
    } else {
      throw Exception("Unable to perform request!");
    }
  }

}