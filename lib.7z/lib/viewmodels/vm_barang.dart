import 'package:flutter/foundation.dart';
import 'package:sahabatjaya/constanta/constanta.dart';
import 'package:sahabatjaya/engines/bits/bits_filter.dart';
import 'package:sahabatjaya/engines/bits/bits_view_model.dart';
import 'package:sahabatjaya/models/barang.dart';
import 'package:sahabatjaya/services/api_bitsnode.dart';
import 'dart:convert';

class ViewModelBarang extends BitsViewModel<Barang> {
  List<GroupBarangDetail> listTipe = List<GroupBarangDetail>();
  int loaded = 0;
  // Map<String, Tipe> listTipe = Map();

  ViewModelBarang() {
    filter.ntabel = "m_item";
    addFieldList("tableid", CJENIS_FILTER_STRING, "", true, true);
    addFieldList("sjid", CJENIS_FILTER_STRING, "", true, true);
    addFieldList("tipe", CJENIS_FILTER_STRING, "", true, true);
    addFieldList("ukuran", CJENIS_FILTER_STRING, "", true, true);
    addFieldList("kode", CJENIS_FILTER_STRING, "", true, true);
    addFieldList("image", CJENIS_FILTER_STRING, "", true, true);
    addFieldList("seri", CJENIS_FILTER_DOUBLE, "", true, true);
    addFieldList("jumlah", CJENIS_FILTER_DOUBLE, "", true, true);
    addFieldList("jumorder", CJENIS_FILTER_DOUBLE, "", true, true);
    addFieldList("harga", CJENIS_FILTER_DOUBLE, "", true, true);
//    addFieldList("status", CJENIS_FILTER_INT, "", false, false);
    getList();
  }

  addOrder(Barang barang) {
    barang.jumorder += 3;
    notifyListeners();
  }

  subOrder(Barang barang) {
    barang.jumorder -= 3;
    notifyListeners();
  }

  loadMore() async {
    print('load more');
    BitsFilter filterGroup = BitsFilter(
      ntabel: 'm_item',
      showField: ["tipe"],
      groupby: "tipe",
      orderby: "Max(edittime) desc",
      limit: 5,
      offset: loaded,
    );

    Map res = await APIBitsNode().getPost(filterGroup);
    List<GroupBarangDetail> curData = groupBarangFromJSON(res['isidata']);
    listTipe.addAll(curData);
    print('DONE load barang: ' + res['jumlahData'].toString());
    this.loaded += res['jumlahData'];
//    listTipe.forEach((group) {
    getListBarang(curData);
  }

  @override
  Future<void> getList() async {
    print('load barang');
//    this.listBarang = await APIBitsNode().getBarang(str);
//    Map res = await APIBitsNode().getPost(filter);
    // this.listBarang = await barangFromJSON(res['isiData'], listTipe);
//    listData = barangFromJSON(res['isidata']);
//    BitsFilter filterTipe = BitsFilter(ntabel: "m_item")
//    this.filter.
//    Map res = await APIBitsNode().postBasicQuery('Select Tipe from m_item group by tipe', []);
    this.loaded = 0;
    this.listTipe.clear();
    loadMore();
//    });
//    generateGroupTipe();
    notifyListeners();
  }

  getListBarang(List<GroupBarangDetail> curData) async {
    this.filter.showField = ['i.*, ci.pesan, ci.jumlah as jumnota'];
    this.filter.ntabel = 'm_item i left join m_customeritem ci on i.tableid = ci.itemid';
    this.filter.orderby = "i.harga";
    await Future.forEach(curData, (group) async {
      print('Get Detail' + group.tipe.nama);
      this.filter.keys.clear();
      this.filter.addDataMap(nField: "tipe", isKey: true, data: group.tipe.nama);
      Map<String, dynamic> res = await APIBitsNode().getPost(this.filter);
      print("Jum data Detail: " + res['jumlahData'].toString());
//      print(res['isidata']);
      group.addListBarang(barangFromJSON(res['isidata']));
      notifyListeners();
    });
  }

  Future<void> generateGroupTipe() async {
    Map<String, GroupBarangDetail> list = Map();
    for (var barang in listData) {
      var x = list.putIfAbsent(barang.tipe, () => GroupBarangDetail(GroupBarang(barang.tipe, barang.image)));
      x.addBarang(barang);      
    }
    listTipe = list.values.toList();
    // listBarang.forEach((barang) => {
    //   // var String x = barang.tipe.tipe;
    //   list.putIfAbsent('x', () => TipeGroup(Tipe(image: 'xx', tipe: 'fadfadsf'), listBarang[0]));
    //   // list.putIfAbsent(barang.tipe.tipe, () => TipeGroup(barang.tipe, barang));
    // });
    // listBarang.map((barang) => list.putIfAbsent(barang.tipe.tipe, () => barang.tipe)).toList();
    // listTipe = list.values.toList();
  }

  Future<void> getListTemp() async {
    // this.listBarang = await barangFromJSON(jsonDecode(
    this.listData = barangFromJSON(jsonDecode(
    '[{"tableid": "coba 1", "kode": "coba 1","nama": "Kei 13859", "tipe": "1-3", "image": null, "jumlah": "10.00", "jumorder": 0, "harga": 83000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 }, ' +
     '{"tableid": "coba 2", "kode": "coba 2","nama": "Kei 13859", "tipe": "4-6", "image": null, "jumlah": 20.00, "jumorder": 0, "harga": 86000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' + 
     '{"tableid": "coba 3", "kode": "coba 3","nama": "Kei 13859", "tipe": "10-14", "image": null, "jumlah": "12", "jumorder": 3, "harga": 90000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' +
     '{"tableid": "coba 2", "kode": "coba 2","nama": "Kei 13859", "tipe": "16-20", "image": null, "jumlah": 20.00, "jumorder": 4, "harga": 93000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' + 
     '{"tableid": "coba 3", "kode": "coba 3","nama": "Kei 13859", "tipe": "22-26", "image": null, "jumlah": "12", "jumorder": 0, "harga": 108000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' +
     '{"tableid": "coba 2", "kode": "coba 2","nama": "Ms 0228.01-05", "tipe": "1-3", "image": null, "jumlah": 20.00, "jumorder": 0, "harga": 69000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' + 
     '{"tableid": "coba 3", "kode": "coba 3","nama": "Ms 0228.01-05", "tipe": "4-6", "image": null, "jumlah": "12", "jumorder": 0, "harga": 72000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' +
     '{"tableid": "coba 2", "kode": "coba 2","nama": "Ms 0228.01-05", "tipe": "7-9", "image": null, "jumlah": 20.00, "jumorder": 0, "harga": 75000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' + 
     '{"tableid": "coba 3", "kode": "coba 3","nama": "Ms 0228.01-05", "tipe": "10-12", "image": null, "jumlah": "12", "jumorder": 12, "harga": 77000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' +
     '{"tableid": "coba 2", "kode": "coba 2","nama": "Ms 0228.01-05", "tipe": "13-15", "image": null, "jumlah": 20.00, "jumorder": 0, "harga": 80000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' + 
     '{"tableid": "coba 3", "kode": "coba 3","nama": "Ms 0228.01-01", "tipe": "1-3", "image": null, "jumlah": "12", "jumorder": 0, "harga": 69000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' +
     '{"tableid": "coba 2", "kode": "coba 2","nama": "Ms 0228.01-01", "tipe": "4-6", "image": null, "jumlah": 20.00, "jumorder": 0, "harga": 72000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' + 
     '{"tableid": "coba 3", "kode": "coba 3","nama": "Ms 0228.01-01", "tipe": "7-9", "image": null, "jumlah": "12", "jumorder": 0, "harga": 75000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 },' +
     '{"tableid": "coba 4", "kode": "coba 4","nama": "Ms 0228.01-01", "tipe": "10-12", "image": null, "jumlah": 36, "jumorder": 0, "harga": 77000.00, "status": 0, "visible": "", "edituser": "", "edittime": null, "isdel": 0 }]'));
    generateGroupTipe();
  }

  @override
  dynamic getDataField(String nField) {

  }

  @override
  void setDataField(String nField, dynamic data) {

  }

  @override
  Future addItem() {

  }

  @override
  Future updateItem() {

  }

  @override
  Future deleteItem() {

  }
}