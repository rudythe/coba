//  final host = 'https://shbjaya.herokuapp.com';
//final host = 'http://nbpv:1000';
const CHOST_ADDR = 'http://nbpv:1000';

const MasterItemID = 'Daftar Barang';
const MasterCustomerID = 'Daftar Pelanggan';

//Constanta jenis filter
const CJENIS_FILTER_TANGGAL = 0;
const CJENIS_FILTER_INT = 1;
const CJENIS_FILTER_STRING = 2;
const CJENIS_FILTER_DOUBLE = 3;
const CJENIS_FILTER_LIST_INT = 4;
// const CJENIS_FILTER_DOUBLE = 3;


// Constanta List
const CLIST_CONDITION_STR = ['begin', 'contains', '='];
const CLIST_CONDITION_ANGKA = [">=", '=', "<=", '>', '<'];
const CLIST_CONDITION_TGL = [">=", '=', "<=", '>', '<'];
const CLIST_CONDITION_LIST_INT = ['='];
